import React, { useEffect } from 'react';

const GoHighLevelForm: React.FC = () => {
  useEffect(() => {
    // Load the GHL form script
    const script = document.createElement('script');
    script.src = 'https://link.msgsndr.com/js/form_embed.js';
    script.async = true;
    document.body.appendChild(script);

    return () => {
      document.body.removeChild(script);
    };
  }, []);

  return (
    <div className="w-full h-[663px] relative">
      <iframe
        src="https://api.leadconnectorhq.com/widget/form/9IvKSkDgCyXd2GGqxCV0"
        style={{
          width: '100%',
          height: '100%',
          border: 'none',
          borderRadius: '3px',
          minHeight: '663px'
        }}
        id="inline-9IvKSkDgCyXd2GGqxCV0"
        data-layout="{'id':'INLINE'}"
        data-trigger-type="alwaysShow"
        data-trigger-value=""
        data-activation-type="alwaysActivated"
        data-activation-value=""
        data-deactivation-type="neverDeactivate"
        data-deactivation-value=""
        data-form-name="JM Home Decor Lead"
        data-height="663"
        data-layout-iframe-id="inline-9IvKSkDgCyXd2GGqxCV0"
        data-form-id="9IvKSkDgCyXd2GGqxCV0"
        title="JM Home Decor Lead"
        allowFullScreen
      />
    </div>
  );
};

export default GoHighLevelForm;